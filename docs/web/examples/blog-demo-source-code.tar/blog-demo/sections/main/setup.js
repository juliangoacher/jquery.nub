function(){
    //var post = $.nub.get('/data/post-pool');
    //$('[data]').nub('/data/post-pool/1');
    
}
