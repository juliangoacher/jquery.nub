(function(){
	var UTIL = {
		elems : [],
		getById:function(){console.log('get by id')},
		addClass:function(){},
		on:function(){},
		appendText:function(){},
		toggleHide:function(){}
	}
	if(!window.$$){window.$$=UTIL;}
})();
